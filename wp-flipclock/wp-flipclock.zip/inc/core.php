<?php

require_once(WPFLIP_WIDGET_PLUGIN_PATH . '/inc/enqueue.php');
require_once(WPFLIP_WIDGET_PLUGIN_PATH . '/inc/display.php');
?>
<?php
/*
Plugin Name: WP Flipclock
Plugin URI: http://winwar.co.uk/plugins/wp-flipclock/
Description: Adds a jQuery Flipclock to the site (based on flipclock.js library)
Version: 0.1
Author: Winwar Media
Author URI: http://winwar.co.uk/
License: GPL2
*/

define('WPFLIP_WIDGET_PLUGIN_PATH', dirname(__FILE__));
require_once(WPFLIP_WIDGET_PLUGIN_PATH . '/inc/core.php');

?>